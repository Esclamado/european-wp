<!-- Generator: Adobe Illustrator 16.0.0, SVG Export Plug-In . SVG Version: 6.00 Build 0)  -->
<svg version="1.1"  xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 width="64px" height="64px" viewBox="0 0 64 64" enable-background="new 0 0 64 64" xml:space="preserve">
<g>
	<g>
		<path fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" d="M32,1c0.672,0,1.339,0.021,2,0.063"/>
		<path fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" stroke-dasharray="4.0593,2.0296" d="M36.021,1.258
			C51.242,3.229,63,16.241,63,32c0,16.104-12.279,29.34-27.986,30.855"/>
		<path fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" d="M34,62.937C33.339,62.979,32.672,63,32,63"/>
	</g>
</g>
<path fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" d="M32,1C14.879,1,1,14.879,1,32
	c0,6.713,2.134,12.926,5.759,18l5.62,5.621"/>
<polyline fill="none" stroke="#000000" stroke-width="2" stroke-linejoin="bevel" stroke-miterlimit="10" points="13,45 13,56 2,56 
	"/>
</svg>
