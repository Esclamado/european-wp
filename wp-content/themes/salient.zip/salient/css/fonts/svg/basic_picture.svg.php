<!-- Generator: Adobe Illustrator 16.0.0, SVG Export Plug-In . SVG Version: 6.00 Build 0)  -->
<svg version="1.1"  xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 width="64px" height="64px" viewBox="0 0 64 64" enable-background="new 0 0 64 64" xml:space="preserve">
<g>
	<rect x="1" y="11" fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" width="62" height="42"/>
	<polyline fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" points="1,47 24,27 36,39 42,31 63,49 	"/>
	<circle fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" cx="51" cy="22" r="5"/>
</g>
</svg>
