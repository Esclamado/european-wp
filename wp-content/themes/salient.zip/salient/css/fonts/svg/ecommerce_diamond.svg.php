<!-- Generator: Adobe Illustrator 16.0.0, SVG Export Plug-In . SVG Version: 6.00 Build 0)  -->
<svg version="1.0"  xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="64px" height="64px" viewBox="0 0 64 64" enable-background="new 0 0 64 64" xml:space="preserve"><g><polyline fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" points="29,6 46,6 63,27 32,58 1,27 18,6 32,6 32,58 	"/>
	<polyline fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" points="32,57 18,27 24,6 "/>
	<polyline fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" points="32,57 46,27 40,6 "/>
	<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="1" y1="27" x2="63" y2="27"/>
</g>
</svg>
