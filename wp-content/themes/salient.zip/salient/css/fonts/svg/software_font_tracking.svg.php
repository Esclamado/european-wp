<!-- Generator: Adobe Illustrator 16.0.0, SVG Export Plug-In . SVG Version: 6.00 Build 0)  -->
<svg version="1.0"  xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 width="64px" height="64px" viewBox="0 0 64 64" enable-background="new 0 0 64 64" xml:space="preserve">
<g>
	<polyline fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" points="9,35 17,12 18,12 26,35 	"/>
	<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="11" y1="28" x2="24" y2="28"/>
</g>
<g>
	<polyline fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" points="38,35 46,12 47,12 55,35 	"/>
	<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="40" y1="28" x2="53" y2="28"/>
</g>
<g>
	<g>
		<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="32" y1="6" x2="32" y2="8"/>
		
			<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" stroke-dasharray="4,2" x1="32" y1="10" x2="32" y2="39"/>
		<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="32" y1="40" x2="32" y2="42"/>
	</g>
</g>
<g>
	<g>
		<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="4" y1="6" x2="4" y2="8"/>
		
			<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" stroke-dasharray="4,2" x1="4" y1="10" x2="4" y2="39"/>
		<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="4" y1="40" x2="4" y2="42"/>
	</g>
</g>
<g>
	<g>
		<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="60" y1="6" x2="60" y2="8"/>
		
			<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" stroke-dasharray="4,2" x1="60" y1="10" x2="60" y2="39"/>
		<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="60" y1="40" x2="60" y2="42"/>
	</g>
</g>
<polyline fill="none" stroke="#000000" stroke-width="2" stroke-linejoin="bevel" stroke-miterlimit="10" points="55,63 62,56 
	55,49 "/>
<polyline fill="none" stroke="#000000" stroke-width="2" stroke-linejoin="bevel" stroke-miterlimit="10" points="9,49 2,56 9,63 
	"/>
<g>
	<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="62" y1="56" x2="2" y2="56"/>
</g>
</svg>
