<!-- Generator: Adobe Illustrator 16.0.0, SVG Export Plug-In . SVG Version: 6.00 Build 0)  -->
<svg version="1.0"  xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 width="64px" height="64px" viewBox="0 0 64 64" enable-background="new 0 0 64 64" xml:space="preserve">
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="43" y1="0" x2="43" y2="12"/>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="43" y1="52" x2="43" y2="64"/>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="21" y1="0" x2="21" y2="6"/>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="21" y1="58" x2="21" y2="64"/>
<rect x="35" y="12" fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" width="16" height="40"/>
<rect x="13" y="6" fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" width="16" height="52"/>
</svg>
