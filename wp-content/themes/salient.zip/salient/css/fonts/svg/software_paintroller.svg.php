<!-- Generator: Adobe Illustrator 16.0.0, SVG Export Plug-In . SVG Version: 6.00 Build 0)  -->
<svg version="1.0"  xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="64px" height="64px" viewBox="0 0 64 64" enable-background="new 0 0 64 64" xml:space="preserve"><rect x="7" y="1" fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" width="48" height="17"/><line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="2" y1="9" x2="7" y2="9"/><polyline fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" points="55,9 61,9 61,24 32,24 32,41 "/>
<rect x="28" y="42" fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" width="8" height="21"/>
</svg>
